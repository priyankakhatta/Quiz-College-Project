
<!DOCTYPE html>
<html>
<body>

<h1>Sign-up Form</h1>

<link rel="stylesheet" type="text/css" href="signin.css">
<form action="includes/signup_inc.php" method ="POST">
 

  <div class="container">
    
    First Name: <input type="text" name="u_f_name" required><br>

    Last Name: <input type="text" name="u_l_name" required><br>

    E-mail: <input type="text" name="u_email" required><br>

    Contact Number: <input type="text" name="u_phone" required><br>

    Address: <input type="text" name="u_address" required><br>

    Enter your password: <input type="password" name="pwd" required><br>
    <br><br> 

     
    <div class="clearfix">
    
    <p style="text-align: center">
      <button type="submit" name ="submit"><b>Sign Up</b></button>
    </p>
    </div>

  </div>

</form>

</body>
</html>