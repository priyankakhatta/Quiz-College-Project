
<?php

	include_once 'header.php';
	
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="home.css">

	</head>

<body>

<article>
	
	<nav>
		<ul>
  <li><a class = "active" href ="admin_question.php">Question</a> </li>&nbsp;&nbsp;
  <li><a href="admin_user.php">Users</a></li>&nbsp;&nbsp;
  <li><a href="logout.php">Logout</a></li>&nbsp;&nbsp;

</ul>

	</nav>
</article>

<p>
<ul>
<li>This is a PHP web application that thoroughly tests the user knowledge of certain topics. </li><br>
<li>The data about the questions are stored in a database. We create two different tests for users to take. It also capture basic user information that took the test as well as store the result of each test for users. </li><br>
<li>The user will have at least 20 questions in certain test. This application selects 10 questions randomly for every user taking a certain test. </li><br>
<li>Once the user selects the test, for every question, user should select one option out of four options presented.</li><br>
<li>When the user answers the last question, the application should display the user’s score. </li>


</ul>
</p>



</body>
</html>