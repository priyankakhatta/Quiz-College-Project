
<?php

	include_once 'header.php';
	
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="home.css">

	</head>

<body>

<article>
	
	<nav>
		<ul>
  <li><a class = "active" href="add_question.php"> Add Question</a> </li><&nbsp;&nbsp;
  <li><a href="delete_question.php">Delete Question</a></li>&nbsp;&nbsp;
  <li><a href="logout.php"> Admin Logout</a></li>&nbsp;&nbsp;
  
</ul>

	</nav>
</article>

</body>
</html>