
<?php

	include_once 'header.php';
	
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="home.css">

	</head>

<body>

<article>
	
	<nav>
		<ul>
  <li><a class = "active" href="home_instr.php">Home</a> </li>&nbsp;&nbsp;
  <li><a href="quiz_disp.php?ques_cat='1'">Educational Quiz</a></li>&nbsp;&nbsp;
  <li><a href="quiz_disp2.php?ques_cat='2'">General Quiz</a></li>&nbsp;&nbsp;
  <li><a href="about.php">About</a></li>&nbsp;&nbsp;
  <li><a href="logout.php">Logout</a></li>&nbsp;&nbsp;
</ul>

	</nav>
</article>
<?php

	include_once 'header.php';
	
?>
<html>
<body>

<title>Home2</title>

<h1> Instructions </h1>

<!-- <img src="C:\xampp\htdocs\KnowledgeAnalysisProject\logo.jpg" style="width:500px;height:400px;"></img> -->
<p>
<ul>
<li>This is a PHP web application that thoroughly tests the user knowledge of certain topics. </li><br>
<li>The data about the questions are stored in a database. We create two different tests for users to take. It also capture basic user information that took the test as well as store the result of each test for users. </li><br>
<li>The user will have at least 20 questions in certain test. This application selects 10 questions randomly for every user taking a certain test. </li><br>
<li>Once the user selects the test, for every question, user should select one option out of four options presented.</li><br>
<li>When the user answers the last question, the application should display the user’s score. </li>


</ul>
</p>

</body>
</html>

</body>
</html>