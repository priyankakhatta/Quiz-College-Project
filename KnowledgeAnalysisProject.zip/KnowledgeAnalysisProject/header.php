<?php
session_start();

?>


<html>
<body style="width: 100%;">
<link rel="stylesheet" type="text/css" href="quiz.css">
<article>
  <header>
    <h1>Knowledge Analysis</h1>
    <p style="margin-left: 152px; margin: 25px 40px; text-align: center;"><i>Test! How genious you are?</i></p>
   
  </header>
</article>


</body>
</html>