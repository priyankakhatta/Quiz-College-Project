<?php 

	session_start();
//checking if radio button's value was sent
	if(isset($_POST['radio']) && $_POST['radio'] != ""){
	//filtering value of radio as it would either be 0/1
		$answer = preg_replace('/[^0-9]/', "", $_POST['radio']);
	//if answer_array isn't set or its count < 1
		if(!isset($_SESSION['answer_array']) || count($_SESSION['answer_array']) < 1){
		//create answer_array & put answer into answer_array as next element
			$_SESSION['answer_array'] = array($answer);
		}else{
		//push answer to already made answer_array
			array_push($_SESSION['answer_array'], $answer);
		}
	}

//checking if qid's value was sent
	if(isset($_POST['qid']) && $_POST['qid'] != ""){
	//filtering qid to numbers as its got to be a no.
		$qid = preg_replace('/[^0-9]/', "", $_POST['qid']);
	//if qid_array isn't set or < 1
		if(!isset($_SESSION['qid_array']) || count($_SESSION['qid_array']) < 1){
		//create qid_array and push qid into it
			$_SESSION['qid_array'] = array($qid);
		}else{
		//push qid into qid_array
			array_push($_SESSION['qid_array'], $qid);
		}

	//the question they have just visited is going to be this lastQuestion session
		$_SESSION['lastQuestion'] = $qid;
	}
?>

<?php
	require_once("includes/dbh_inc.php");

	$response = ""; 
	
//if answer_array isn't set or count < 1
//they will never ever see this, if they do, something is terribly terribly wrong!
	if(!isset($_SESSION['answer_array']) || count($_SESSION['answer_array']) < 1){
		$response = "You have not answered any questions yet";
		echo $response;
		exit();
	}else{
	//getting all qIDs from database and counting the no. of questions
		$countCheck = mysqli_query("SELECT id FROM question_answers")or die(mysql_error());
		$count = mysqli_num_rows($countCheck);
	//correct answers user got initialized to zero
		$numCorrect = 0;

	//looping through answer_array to check how many correct answers user got
		foreach($_SESSION['answer_array'] as $current){
			if($current == 1){
				$numCorrect++;
			}
		}

	//calculating Percentage and converting to int
		$percent = $numCorrect / $count * 100;
		$percent = intval($percent);

	// //from questions.php relating to getting done with last question
	// 	if(isset($_POST['complete']) && $_POST['complete'] == "true"){
	// 		if(!isset($_POST['username']) || $_POST['username'] == ""){
	// 			echo "Sorry, We had an error as you failed to enter the username";
	// 			exit();
	// 		}
	// 	//adding username to var and securing it
	// 		$username = $_POST['username'];
	// 		$username = mysqli_real_escape_string($username);
	// 		$username = strip_tags($username);

	// 	//check if atleast one correct answer is there
	// 		if(!in_array("1", $_SESSION['answer_array'])){
	// 			$sql = mysqli_query("INSERT INTO quiz_takers (username, percentage, date_time) 
	// 								VALUES ('$username', '0', now())")or die(mysql_error());
	// 			echo "Did you even read the questions? You scored $percent%, You must be retarded.";
	// 			unset($_SESSION['answer_array']);
	// 		//can be added to index.php to remove that once error thing
	// 			unset($_SESSION['qid_array']);
	// 			session_destroy();
	// 			exit();
	// 		}
		
	// 	//just insert user info in the table!
	// 		$sql = mysql_query("INSERT INTO quiz_takers (username, percentage, date_time) 
	// 							VALUES ('$username', '$percent', now())")or die(mysql_error());
			echo "Thanks for taking the quiz! You scored $percent%";
			unset($_SESSION['answer_array']);
			unset($_SESSION['qid_array']);
			session_destroy();
			exit();
		}
	}
?>