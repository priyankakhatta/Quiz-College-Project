<!DOCTYPE html>
<html>
<body>

<h1>Login Form</h1>

<link rel="stylesheet" type="text/css" href="signin.css">
<form action="includes/login_inc.php" method = "POST">
 

  <div class="container">
    <label><b>Email</b></label>
    <input type="text" placeholder="Enter Your Email" name="email" required>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pwd" required>
     
     <p style="text-align: center">   
    <button type="submit" name = "submit">Login</button><br>
    <b> Or </b><br>
   	Create an account, click on <a href="signup.php"> Sign-up </a><br>
   	<b> Or </b><br>

   	<button type="button" name="admin" style="background-color:#C0C0C0 "><a class = "ad" href="admin_login.php"> Admin Login </a></button>


	</p>
  
  </div>

</form>

</body>
</html>