-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 22, 2017 at 04:22 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `KnowledgeAnalysis`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `correct` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer`, `correct`) VALUES
(1, 1, 'True', '1'),
(2, 1, 'False', '0'),
(3, 2, 'aqdcx ', '1'),
(4, 2, 'nbcnb', '0'),
(5, 2, 'nmvgd', '0'),
(6, 2, 'opopipoipoi', '0');

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_no` int(11) NOT NULL,
  `question_category` varchar(256) NOT NULL,
  `is_correct` int(11) NOT NULL,
  `text` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mst_result`
--

CREATE TABLE `mst_result` (
  `login` varchar(20) DEFAULT NULL,
  `test_id` int(5) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `score` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_result`
--

INSERT INTO `mst_result` (`login`, `test_id`, `test_date`, `score`) VALUES
('raj', 8, '0000-00-00', 3),
('raj', 9, '0000-00-00', 3),
('raj', 8, '0000-00-00', 1),
('ashish', 10, '0000-00-00', 3),
('ashish', 9, '0000-00-00', 2),
('ashish', 10, '0000-00-00', 0),
('raj', 8, '0000-00-00', 0),
('ankur', 11, '0000-00-00', 0),
('', 1, '0000-00-00', 2),
('', 1, '0000-00-00', 4),
('', 1, '0000-00-00', 0),
('', 1, '0000-00-00', 1),
('', 1, '0000-00-00', 2),
('', 1, '0000-00-00', 1),
('', 1, '0000-00-00', 3),
('', 1, '0000-00-00', 4),
('', 1, '0000-00-00', 2),
('', 1, '0000-00-00', 0),
('', 1, '0000-00-00', 1),
('', 1, '0000-00-00', 4),
('', 1, '0000-00-00', 6),
('', 1, '0000-00-00', 3),
('', 1, '0000-00-00', 2),
('', 1, '0000-00-00', 2),
('', 1, '0000-00-00', 4),
('', 1, '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mst_useranswer`
--

CREATE TABLE `mst_useranswer` (
  `sess_id` varchar(80) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `que_des` varchar(200) DEFAULT NULL,
  `ans1` varchar(50) DEFAULT NULL,
  `ans2` varchar(50) DEFAULT NULL,
  `ans3` varchar(50) DEFAULT NULL,
  `ans4` varchar(50) DEFAULT NULL,
  `true_ans` int(11) DEFAULT NULL,
  `your_ans` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_useranswer`
--

INSERT INTO `mst_useranswer` (`sess_id`, `test_id`, `que_des`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`, `your_ans`) VALUES
('2b8e3337837b82112def8d3e2f42f26e', 8, 'What  Default Data Type ?', 'String', 'Variant', 'Integer', 'Boolear', 2, 1),
('2b8e3337837b82112def8d3e2f42f26e', 8, 'What is Default Form Border Style ?', 'Fixed Single', 'None', 'Sizeable', 'Fixed Diaglog', 3, 3),
('2b8e3337837b82112def8d3e2f42f26e', 8, 'Which is not type of Control ?', 'text', 'lable', 'checkbox', 'option button', 1, 3),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 1),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 1),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 2),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 3),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 4),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 4),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 3),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 2),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 2),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 1),
('idjir9pcq2d07764us8rdiq9n5', 11, 'how to use date( ) in mysql ?', 'now( )', 'today( )', 'date( )', 'time( )', 0, 1),
('05061hfh5smajc416hoarbrl83', 1, 'What does PHP stand for?', 'Personal Home Page/Pretext Hypertext Processor', 'Hypertext Preprocessor/Preprocessor Home Page', 'Hypertext Preprocessor', 'Personal Home Page/Hypertext Preprocessor', 4, 1),
('05061hfh5smajc416hoarbrl83', 1, 'Which keyword precedes a method name?', 'method', 'function', 'public', 'protected', 2, 3),
('05061hfh5smajc416hoarbrl83', 1, 'PHP files have a default file extension of....', '.html', '.xml', '.php', '.ph', 3, 2),
('05061hfh5smajc416hoarbrl83', 1, 'Which version of PHP introduced Try/ Catch Exception? ', 'PHP4', 'PHP5', 'PHP5.3', 'PHP6', 2, 1),
('05061hfh5smajc416hoarbrl83', 1, 'Who is the father of PHP?', 'Rasmus Lerdorf', 'William Markepiece', 'Derk Kolkevi', 'List Barely', 1, 3),
('05061hfh5smajc416hoarbrl83', 1, 'Which version of PHP introduced the visibility keywords i.e. Public, Private and Protected?', 'PHP4', 'PHP5', 'PHP5.1', 'PHP5.3', 2, 2),
('05061hfh5smajc416hoarbrl83', 1, 'Who is the father of PHP?', 'Rasmus Lerdorf', 'William Markepiece', 'Derk Kolkevi', 'List Barely', 1, 4),
('05061hfh5smajc416hoarbrl83', 1, 'PHP files have a default file extension of....', '.html', '.xml', '.php', '.ph', 3, 2),
('05061hfh5smajc416hoarbrl83', 1, 'Code that uses a class, function, or method is often described as the..', 'Client code', 'User code', 'Object code', 'Class code', -1, 4),
('05061hfh5smajc416hoarbrl83', 1, 'Which one of the following is NOT a valid class name?', 'ShopProduct', 'Shopproduct', 'Shopproduct1', '1shopproduct', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_id` int(11) NOT NULL,
  `question_no` int(11) NOT NULL,
  `question_cat` varchar(256) NOT NULL,
  `question_text` varchar(2560) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_id`, `question_no`, `question_cat`, `question_text`) VALUES
(1, 0, 'educational', 'what your dream subject?');

-- --------------------------------------------------------

--
-- Table structure for table `question_answers`
--

CREATE TABLE `question_answers` (
  `id` int(11) NOT NULL,
  `ques_cat` int(11) NOT NULL,
  `ques_text` varchar(255) NOT NULL,
  `ch1` varchar(255) NOT NULL,
  `ch2` varchar(255) NOT NULL,
  `ch3` varchar(255) NOT NULL,
  `ch4` varchar(255) NOT NULL,
  `ans` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_answers`
--

INSERT INTO `question_answers` (`id`, `ques_cat`, `ques_text`, `ch1`, `ch2`, `ch3`, `ch4`, `ans`) VALUES
(1, 1, 'Which of  the following statements is equivalent to $add+=$add?', '$add=$add', '$add=$add+$add', '$add=$add+1', '$add =$add +$add+1', 2),
(2, 1, 'Which statement will output $x on the screen?', 'echo\"$x\";', 'echo\"$$x\";', 'echo\"/$x\";', 'echo\"$x;\";', 1),
(3, 1, 'What does PHP stand for?', 'Personal Home Page/Pretext Hypertext Processor', 'Hypertext Preprocessor/Preprocessor Home Page', 'Hypertext Preprocessor', 'Personal Home Page/Hypertext Preprocessor', 4),
(4, 1, 'PHP files have a default file extension of....', '.html', '.xml', '.php', '.ph', 3),
(5, 1, 'A PHP script should start with ___ and end with ___ :', '\'<php, >\'', '\'<?php, ?>\'', '\'<?, php?>\'', '\'<?php, ?>\'', 4),
(6, 1, 'Which of the following is/are a PHP code editor?', 'Only PDT', 'All of the mentioned', 'Notepad, Notepad++, PDT', 'Sublime', 2),
(7, 1, 'Which of the must be installed on your computer so as to run PHP script?', 'Only Adobe Dreamweaver', 'Only PHP', 'PHP, Apache', 'PHP, Apache, IIS', 4),
(8, 1, 'Which version of PHP introduced Try/ Catch Exception? ', 'PHP4', 'PHP5', 'PHP5.3', 'PHP6', 2),
(9, 1, 'We can use ___ to comment a single line?', 'Only //', '/?, # and /* */', '//, # and /* */', 'Both // and /* */', 3),
(10, 1, 'Which of the following PHP statement(s) will store 111 in variable num?', 'int $num = 111;', 'int num = 111;', '$num = 111;', 'All of the mentioned', 3),
(11, 1, 'Which one of the following is NOT a valid class name?', 'ShopProduct', 'Shopproduct', 'Shopproduct1', '1shopproduct', 4),
(12, 1, 'Fill in the blank with the best option. An object is a/an ___ of a class.', 'type', 'prototype', 'instance', 'object', 3),
(13, 1, 'Which version of PHP introduced the visibility keywords i.e. Public, Private and Protected?', 'PHP4', 'PHP5', 'PHP5.1', 'PHP5.3', 2),
(14, 1, 'Which character is used to access property variables on an object-by-object basis?', '::', '=', '->', '.', 3),
(15, 1, 'Code that uses a class, function, or method is often described as the..', 'Client code', 'User code', 'Object code', 'Class code', -1),
(16, 1, 'Which keyword precedes a method name?', 'method', 'function', 'public', 'protected', 2),
(17, 1, 'If you omit the visibility keyword in your method declaration, by default the method will be declared as....', 'public', 'private', 'protected', 'friendly', 1),
(18, 1, 'Which function is used to determine whether the variables value is either TRUE or FALSE?', 'boolean()', 'is_boolean()', 'bool()', 'is_bool()', 4),
(19, 1, 'Who is the father of PHP?', 'Rasmus Lerdorf', 'William Markepiece', 'Derk Kolkevi', 'List Barely', 1),
(20, 1, 'If $a=12 what will be returned when ($a==12)? 5:1 is executed?', '12', '1', 'Error', '5', 4),
(21, 2, 'What is a Francophone?', 'A person who speak english as their first language', 'A smartphone designed by the Canadian company RIM', 'A person who speak French as their first language', 'The first phone in Canada, invented by Alexander Graham Bell', 3),
(22, 2, 'In 2011, how many people in Canada considered themselves bilingual in English and French? ', '4.8 million', '5.8 million', '6.8 million', '6.0 million', 2),
(23, 2, 'In which year of First World War Germany declared war on Russia and France?', '1914', '1915', '1916', '1917', 1),
(24, 2, 'When did Montreal host Olympics?', '1964', '1976', '1980', '1984', 2),
(25, 2, 'Who was the Prime Minister of Canada from 1968 to 1979?', 'Pierre Elliot Trudeau', 'John Napier Turner', 'Kim Campbell', 'Martin Brian Mulroney', 1),
(26, 2, 'Which is the Capital of Canada?', 'Ottawa', 'Monreal', 'Halifax', 'Toronto', 1),
(27, 2, 'Who is the patron saint of Canada? ', 'St.David', 'St.Andrew', 'St.George', 'St.Jean de Brebeuf', 4),
(28, 2, 'Which are the official languages of Canada?', 'English and Spanish', 'Spanish and French', 'French and Russian', 'English and French', 2),
(29, 2, 'Which of the following is not a province of Canada?', 'Alberta', 'British Columbia', 'Rhode Island', 'Quebec', 3),
(30, 2, 'Who said \"The medium is the message.\"?', 'Stephen Harper', 'Marshall McLuhan', 'Jeanne Suave', 'Nelly Furtado', 2),
(31, 2, 'Which of the following island is not a part of Canada?', 'Greenland', 'Baffin Island', 'Victoria Island', 'Prince Edward Island', 1),
(32, 2, 'Which country has larger area than Canada?', 'Russia', 'China', 'USA', 'Brazil', 1),
(33, 2, 'who is the Head of State of Canada?', 'President', 'Governor General', 'Monarch of UK', 'Prime Minister', 3),
(34, 2, 'Which country is on the south of Canada?', 'Norway', 'USA', 'Mexico', 'Brazil', 2),
(35, 2, 'Which are the two Houses of Canadian Parliament?', 'House of Lords and House of Commons', 'Council of states and House of Peoples', 'Senate and House of Commons ', 'Senate and House of Representatives', 3),
(36, 2, 'which is the highest mountain in Canada?', 'Fairweather', 'Morseby', 'Logan', 'Admant', 3),
(37, 2, 'Canada has how many time zones?', 'Three', 'Four', 'Five', 'Six', 4),
(38, 2, 'Who won the Olympic gold medal in 100 meter race in Atlanta Olympics 1996?', 'Jesse Owens', 'Donovan Bailey', 'Ben johnson', 'Carl Lewis', 2),
(39, 2, 'Who is the first Canadian Cardinal?', 'Louis Nazaire Begin', 'James Chares McGuigan', 'Felix Raymond Marie Rouleau', 'Elzear Alexandre Taschereau', 4),
(40, 2, 'Where was Jesuit missionary Isaac Jogues born?', 'London', 'Paris', 'Orleans', 'Rome', 3),
(41, 2, 'Which province is the only officially bilingual province?', 'New Brunswick', 'Quebec', 'Ontario', 'Prince Edward Island', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_first_name` varchar(256) NOT NULL,
  `user_last_name` varchar(256) NOT NULL,
  `user_email` varchar(256) NOT NULL,
  `user_phone` varchar(256) NOT NULL,
  `user_address` varchar(256) NOT NULL,
  `user_password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_first_name`, `user_last_name`, `user_email`, `user_phone`, `user_address`, `user_password`) VALUES
(1, 'p', 'k', 'k@gmail.com', '1234512345', '25 bay mills', '123'),
(2, 'priyanka', 'khatta', 'khattapriyanka@gmail.com', '4168354015', '25 bay mills', '$2y$10$hyZxm6ZI9EFsRoNK4CZz6eFuHpWeDCqHSvY4O8n5J83n0C9g1Hi1W'),
(3, 'pp', 'kk', 'pk@gmail.com', '1231231231', '222', '$2y$10$QhpM.OgdiGZI3qqG4vZWgOVfZGruxOYfwGT8VDKGvgz/T3sLVjdvC'),
(4, 'Mandeep', 'sidhu', 'ms@gmail.com', '1234512345', '385 mil street south', '$2y$10$s.XEBxSx86hThnWzD1HHRO.OAtxH2fOyJbS/rszSEuq6TK6ChyM9a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `question_answers`
--
ALTER TABLE `question_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `question_answers`
--
ALTER TABLE `question_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
