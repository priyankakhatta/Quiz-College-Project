<?php

	include_once 'header.php';
	
?>

<html>

<body>

<title>Home2</title>

<h2> About </h2>

<p>

The propositional knowledge that is the analysandum of the analysis of knowledge literature is paradigmatically expressed in English by sentences of the form “S knows that p”, where “S” refers to the knowing subject, and “p” to the proposition that is known. A proposed analysis consists of a statement of the following form: S knows that p if and only if j, where j indicates the analysans: paradigmatically, a list of conditions that are individually necessary and jointly sufficient for S to have knowledge that p. Quiz tests are basically on Educational i.e. PHP and General i.e. Canada Awareness Topics.

</p>

<p>
PHP is a free source that teaches those who are interested in learning the PHP language, quickly and easily. Another key piece of information one should know would be, anyone visiting this website to learn about PHP coding  is expected to have some basic knowledge about HTML and PHP code.  If you have experience in other high level languages, the PHP basics should be a breeze to learn, and if you have no experience, our goal is to make the basics a breeze to learn.
</p>
<p>
This site is not intended to be a source for becoming an advance PHP programmer, but a website designed to give new individuals to the PHP language basic understanding of the core components to PHP programming. If you are already an intermediate or advance programmer, the video tutorials within this website will most likely be too easy for you or too slow paced. For most individuals new to a particular coding language require an easy and slow pace teaching environment, but some individuals catch on quickly. 
</p>
</body>
</html>