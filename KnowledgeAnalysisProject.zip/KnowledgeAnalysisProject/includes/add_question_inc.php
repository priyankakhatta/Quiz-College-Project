<?php
 if(isset($_POST['submit'])){

 include_once 'dbh_inc.php';


 	$question_cat = $_POST['ques_cat'];
 	$question_text = $_POST['ques'];
 	$ans = $_POST['ans'];
 	//$question_no = $_POST['ques_no'];

 	$choices =array();
 	$choice1 = $_POST['ch1'] ;

 	$choice2 = $_POST['ch2'] ;

 	$choice3 = $_POST['ch3'] ;

 	$choice4 = $_POST['ch4'] ;

 if (empty($question_cat)||empty($question_text)||empty($ans)||empty($choice1)||empty($choice2)||empty($choice3)||empty($choice4)) {
        header("Location: ../add_question.php?add_question=empty");
        exit();
    }
    else{

 	$query = "INSERT INTO question_answers (ques_cat,ques_text,ch1,ch2,ch3,ch4,ans) 
 	VALUES ('$question_cat','$question_text','$choice1','$choice2','$choice3','$choice4','$ans');";

 	mysqli_query($conn,$query);
 	echo "Add new Question..." ;
 	header("Location: ../add_question.php?add_ques=successfull");
                    exit();

 }

 	//if($insert_row){
 	//	foreach ($choices as $choice => $value) {
 	//		if($value != ''){
 	//			if($ans == $choice)
 	//				$is_correct = 1;
 	//			else
 	//				$is_correct = 0;

 	//		} 	

 	//	}

	//$msg = 'Question has been added';
 	//}

 }
?>
