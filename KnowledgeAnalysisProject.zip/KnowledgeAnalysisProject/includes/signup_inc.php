<?php


if(isset($_POST['submit'])){
    
    include_once 'dbh_inc.php';
    
    $firstname = mysqli_real_escape_string($conn, $_POST['u_f_name']);
    $lastname = mysqli_real_escape_string($conn, $_POST['u_l_name']);
    $email = mysqli_real_escape_string($conn, $_POST['u_email']);
    $phone = mysqli_real_escape_string($conn, $_POST['u_phone']);
    $address = mysqli_real_escape_string($conn, $_POST['u_address']);
    $password = mysqli_real_escape_string($conn, $_POST['pwd']);

    //Error handlers
    // check for empty fields
    if (empty($firstname)||empty($lastname)||empty($email)||empty($phone)||empty($address)||empty($password)) {
        header("Location: ../signup.php?signup=empty");
        exit();
    }
    else{
        //check if input caharacters are valid
        if (!preg_match("/^[a-zA-Z]*$/", $firstname)||!preg_match("/^[a-zA-Z]*$/", $lastname)){
            header("Location: ../signup.php?signup=invalid");
            exit();
        }
        else {
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                header("Location: ../signup.php?signup=invalid_email");
                exit();
            }
            else{
                $sql = "SELECT * FROM users WHERE user_email = '$email' ";
                $result = mysqli_query($conn, $sql);
                $resultCheck = mysqli_num_rows($result);
                
                if($resultCheck > 0){
                    header("Location: ../signup.php?signup=aleadyUser");
                    exit();
                }
                else {
                    // Hashing the password
                    $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $sql = "INSERT INTO users (user_first_name, user_last_name, user_email, user_phone, user_address, user_password) VALUES ('$firstname', '$lastname', '$email', '$phone', '$address', '$hashedPwd') ;" ;

                    mysqli_query($conn, $sql); 
                    header("Location: ../signup.php?signup=successfull");
                    exit();
                    
                }
            }

        }
    }

}
else{
    header("Location: ../signup.php");
    exit();
}

