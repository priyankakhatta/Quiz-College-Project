<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "KnowledgeAnalysis";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
$mysqli = new mysqli($dbServername,$dbUsername,$dbPassword,$dbName);


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}