<?php


session_start();

$msg = "";

if(isset($_POST['admin'])){

header("Loaction: ../admin_login.php?login=admin");
			exit();


}



if(isset($_POST['submit']))
{
	

	include 'dbh_inc.php';

	echo $msg ;
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$pwd = mysqli_real_escape_string($conn,$_POST['pwd']);

	//error handlers
	//check if inputs are empty
	if(empty($email) || empty($pwd))
	{
		header("Location: ../index.php?login=empty");
		$msg = "All Fields Requied" ;
		exit();
	}

	else{
		$sql = "SELECT * FROM users WHERE user_email = '$email'";
		$result = mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);

		if($resultCheck < 1){
					$msg = "Email not match" ;

			header("Location: ../index.php?login=error");
			exit();

		}
		else{
			if($row = mysqli_fetch_assoc(($result))){
				//De-hashing the password
				$hashedPwdCheck = password_verify($pwd,$row['user_password']);
				if($hashedPwdCheck == false){
					$msg = "Password incorrect" ;

					header("Location: ../index.php?login=error");
					exit();
				}
				else if($hashedPwdCheck == true){
					//log in the user here 

					$_SESSION['u_id'] = $row['user_id'];
					$_SESSION['u_first_name'] = $row['user_first_name'];
					$_SESSION['u_last_name'] = $row['user_last_name'];
					$_SESSION['u_email'] = $row['user_email'];
					$_SESSION['u_phone'] = $row['user_phone'];
					$_SESSION['u_address'] = $row['user_address'];
					header("Location: ../home.php?login=success");
					exit();
				}
			}

			}
		

		}
	
}
else{
	header("Location: ../index.php?login=error");

					$msg = "Error" ;
	exit();
}