<?php
	session_start();

/*CAN WE UNSET HERE? I can't
	unset($_SESSION['answer_array']);
	unset($_SESSION['qid_array']);
*/

//seeing if in URL question=something!!
//if its question 1, it gets value from index.php
	if(isset($_GET['question'])){
	//making question var which contains question number filter to only numbers
		$question = preg_replace('/[^0-9]/', "", $_GET['question']);
	//next and previous question number
		$next = $question + 1;
		$prev = $question - 1;

	//just went to ?question=2 or 3 ==> NO CHEATING
		if(!isset($_SESSION['qid_array']) && $question != 1){
			$msg = "Sorry! No cheating.";
			header("location: edu_quiz.php?msg=$msg");
			exit();
		}

	//in_array - search first parameter into second array
	//checking if qid_array is set, and question number has already been visited
		if(isset($_SESSION['qid_array']) && in_array($question, $_SESSION['qid_array'])){
			$msg = "Sorry, Cheating is not allowed. You will now have to start over. Haha. qid";
			unset($_SESSION['answer_array']);
			unset($_SESSION['qid_array']);
		// so that all the sessions are taken care of
			session_destroy();
			header("location: edu_quiz.php?msg=$msg");
			exit();
		}

	//if question=1 this if won't even run as userAnswers.php hasn't been executed yet

		if(isset($_SESSION['lastQuestion']) && $_SESSION['lastQuestion'] != $prev){
			$msg = "Sorry, Cheating is not allowed. You will now have to start over. Haha. lQ";
			unset($_SESSION['answer_array']);
			unset($_SESSION['qid_array']);
		// so that all the sessions are taken care of
			session_destroy();
			header("location: edu_quiz.php?msg=$msg");
			exit();
		}
	}
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Quiz Page</title>
		
		<!-- <script type="text/javascript">

			function countDown(secs,elem) {
				var element = document.getElementById(elem);
				element.innerHTML = "You have "+secs+" seconds remaining.";
				if(secs < 1) {
					var xhr = new XMLHttpRequest();
					var url = "userAnswers.php";
				//setting vars to send incorrect as the answer
					var vars = "radio=0"+"&qid="+<?php echo $question; ?>;
					
					xhr.open("POST", url, true);
					xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					
					xhr.onreadystatechange = function() {
						if(xhr.readyState == 4 && xhr.status == 200) {
							alert("You did not answer the question in the allotted time. It will be marked as incorrect.");
							clearTimeout(timer);
						}
					}
				
				//sending the incorrect answer awa qID to userAnswers.php
					xhr.send(vars);

				//changing the page accordingly
					document.getElementById('counter_status').innerHTML = "";
					document.getElementById('btnSpan').innerHTML = '<h2>Times Up!</h2>';
					document.getElementById('btnSpan').innerHTML += '<a href="quiz.php?question=<?php echo $next; ?>">Click here now</a>';
			
				}

			//decreasing the seconds var
				secs--;
				
			//to animate the counter otherwise it'd just stay at the number entered
			//calling countdown() again after 1 sec
				var timer = setTimeout('countDown('+secs+',"'+elem+'")',1000);
			}
		</script> -->
	
		<script>
		//getting a question and putting it on webpage is done here
			function getQuestion(){
				var hr = new XMLHttpRequest();
				hr.onreadystatechange = function(){
					if (hr.readyState==4 && hr.status==200){
					//splitting the response and checking for last question
						var response = hr.responseText.split("|");
						if(response[0] == "finished"){
							document.getElementById('status').innerHTML = response[1];
						}
					//splitting the response to divide question and answers
						var nums = hr.responseText.split(",");
						document.getElementById('id').innerHTML = nums[0];
						document.getElementById('ques_text').innerHTML = nums[1];
						document.getElementById('ans').innerHTML += nums[2];
					}
				}
			
				hr.open("GET", "ques_disp.php?question=" + <?php echo $question; ?>, true);
				hr.send();
			}
			
		//getting the checked radio button from here
			function x() {
				var rads = document.getElementsByName("rads");
				for ( var i = 0; i < rads.length; i++ ) {
					if ( rads[i].checked ){
						var val = rads[i].value;
						return val;
					}
				}
			}
	
			function post_answer(){
				var p = new XMLHttpRequest();
			//question ID from questions.php
				var id = document.getElementById('qid').value;

				var correct_ans = document.getElementById('ans').value;
			//sending it to URL==
				var url = "userAnswers.php";
			//what we are sending question ID and the checked radio button
				var vars = "qid="+id+"&radio="+x();
			//opening AJAX connection as POST, to the URL userAnswers.php with async=true
				p.open("POST", url, true);
				p.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				p.onreadystatechange = function() {
					if(p.readyState == 4 && p.status == 200) {
					//clearing everything out of the page if everything runs smoothly
						document.getElementById("status").innerHTML = '';
						alert("Thanks, Your answer was submitted"+ p.responseText);
					//going to the next question
						var url = 'test_quiz.php?question=<?php echo $next; ?>';
						window.location = url;
					}
				}
			
			//sending vars variable value to userAnswers.php
				p.send(vars);
				document.getElementById("status").innerHTML = "processing...";	
			}
		</script>


	<!-- preventing right click -->
		<script>
			window.oncontextmenu = function(){
				return false;
			}
		</script>
	</head>

	<body onLoad="getQuestion()">
		<div id="status">
			<div id="counter_status"></div>
			<div id="question"></div>
			<div id="answers"></div>
		</div>
		
	<!--countdown script here-->
		<!-- <script type="text/javascript">countDown(60,"counter_status");</script> -->
	</body>
</html>