<?php

session_start();

$msg = "";
if(isset($_POST['submit']))
{
	

	include 'dbh_inc.php';

	echo $msg ;
	$username = mysqli_real_escape_string($conn,$_POST['username']);
	$pwd = mysqli_real_escape_string($conn,$_POST['pwd']);

	//error handlers
	//check if inputs are empty
	if(empty($username) || empty($pwd))
	{
		header("Location: ../index.php?login=empty");
		$msg = "All Fields Requied" ;
		exit();
	}

	else{

		if($username == 'admin' && $pwd == 'admin'){

			header("Location: ../admin_home.php?login=success");
			exit();
			
		}
	}	
}
else{
	header("Location: ../index.php?login=error");
	$msg = "Error" ;
	exit();
}