
<?php

	include_once 'header.php';
	
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="home.css">

	</head>

<body>

<article>
	
	<nav>
		<ul>
  <li><a class = "active" href="admin_question.php">Question</a> </li><&nbsp;&nbsp;
  <li><a href="users.php">Users</a></li>&nbsp;&nbsp;
  <li><a href="logout.php"> Admin Logout</a></li>&nbsp;&nbsp;
  
</ul>

	</nav>
</article>

</body>
</html>