<!DOCTYPE html>
<html>
<body>

<h1> Admin Login Form</h1>

<link rel="stylesheet" type="text/css" href="signin.css">
<form action="includes/admin_login_inc.php" method = "POST">
 

  <div class="container">
    <label><b>Username</b></label>
    <input type="text" placeholder="username" name="username" required>

    <label><b>Password</b></label>
    <input type="password" placeholder="password" name="pwd" required>
     
     <p style="text-align: center">   
    <button type="submit" name = "submit" >Admin Login</button><br>
   
   

	</p>
  
  </div>

</form>

</body>
</html>