
<?php

	include_once 'admin_question.php';
	
?>
<html>
<style>
	
	label{
		display: inline-block;
		width: 180px;

	}
	.txt{
		margin: 20px;
		background-color: #C0C0C0;
		border: 10px solid #f1f1f1;
    	width: 92%; height: 80%;
    	padding: 20px;

	}
</style>
<body>

<h1> Add Question </h1>
<br>
<div class = "txt">
<form method = 'POST'  action = 'includes/add_question_inc.php' >
	<p>
		<label> Question Category :      </label>
<select name="ques_cat">
  <option value="educational" selected>Educational</option>
  <option value="general">General</option>
</select>

	</p>

	<p>
		<label> Question : </label>
		<input type="text" name="ques" />
	</p>
	<p>
		<label> Choice 1 : </label>
		<input type="text" name="ch1" />
	</p>
	<p>
		<label> Choice 2 : </label>
		<input type="text" name="ch2" />
	</p>
	<p>
		<label> Choice 3 : </label>
		<input type="text" name="ch3" />
	</p>
	<p>
		<label> Choice 4 : </label>
		<input type="text" name="ch4" />
	</p>
	<p>
		<label> Answer : </label>
		<input type="number" name="ans" />
	</p>
	
<button type="submit" name="submit" style="width:25%"; align:"center"> Submit </button>


</form>
</div>


</body>

</html>
